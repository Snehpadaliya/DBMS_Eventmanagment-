<title>cec1</title>
<style>
.bgImage {
    background-image: url(https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=2148&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D);
    background-size: cover;
    background-position: center center;
    height: 650px;
    margin-bottom: 25px;
}
</style>
<header class="bgImage" >
    <nav class="navbar" >
        <div class="container">
        <div class="navbar-header"><!--website name/title-->  
                <a class = "navbar-brand">
                   <h2>EVENTHUB</h2>
                </a>
        </div>

            <ul class="nav navbar-nav navbar-right"><!--navigation-->
                    <li><a href = "index.php"><strong>Home</strong></a></li>
                    <li><a href = "register.php"><strong>Register</strong></a></li>
                    <li><a href = "contact.php"><strong>Contact Us</strong></a></li>
                    <li><a href = "aboutus.php"><strong>About us</strong></a></li>
                    <li class="btnlogout"><a class = "btn btn-default navbar-btn" href = "login_form.php">Login <span class = "glyphicon glyphicon-log-in"></span></a></li>

                
            </ul>
        </div><!--container div-->
    </nav>
    <div class = "col-md-12">
        <div class = "container">
            <div class = "jumbotron"><!--jumbotron-->
                <h1> EVENT HUB </h1><!--jumbotron heading-->
                <!-- <h2>~event by ASK</h2> -->
                <br><div class="browse d-md-flex col-md-14" >
                <div class="row">
                  
            </div>
        </div>
    </div>
</header>