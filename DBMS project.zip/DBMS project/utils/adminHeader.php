<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>cec1</title>
    <style>
        .bgImage {
            background-image: url(https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=2148&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D);
            background-size: cover;
            background-position: center center;
            height: 600px;
            margin-bottom: 29px;
        }
    </style>
</head>

<?php require 'utils/styles.php'; ?>


<header class="bgImage">
    <nav class="navbar">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand">
                    EVENTHUB
                </a>
            </div>
            <ul class="nav navbar-nav navbar-right"><!--navigation-->
                <li><a href="adminPage.php"><strong>Home</strong></a></li>
                <li><a href="Stu_details.php"><strong>Student Details</strong></a></li>
                <li><a href="Stu_cordinator.php"><strong>Student Co-ordinator</strong></a></li>
                <li><a href="Staff_cordinator.php"><strong>Staff-Co-ordinator</strong></a></li>
                <li class="btnlogout"><a class="btn btn-default navbar-btn" href="index.php">Logout <span class="glyphicon glyphicon-log-out"></span></a></li>

            </ul>
        </div><!--container div-->
    </nav>
    <div class="col-md-12">
        <div class="container">
            <div class="jumbotron"><!--jumbotron-->
            <h1> EVENT HUB </h1>
                <!-- <h2>~event by ASK</h2> -->
                <div class="browse d-md-flex col-md-14">
                    <div class="row">

                    </div>
                </div>
            </div>
</header>